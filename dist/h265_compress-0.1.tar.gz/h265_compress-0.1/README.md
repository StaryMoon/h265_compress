# h265_compress

A Python library to compress YUV files to H.265 MP4 format using ffmpeg-python.

## Installation

To install the library, run:

```bash
pip install h265_compress