from setuptools import setup, find_packages

setup(
    name="h265_compress",  # 这里是你的库名
    version="0.1",  # 库的版本号
    packages=find_packages(),
    install_requires=[
        'ffmpeg-python',  # 依赖的库
    ],
    description="A Python library to compress YUV files to H.265 MP4.",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    author="Minghao Liu", 
    author_email="minghao13187@gmail.com",
    # url="https://github.com/yourusername/h265_compress",  # 项目的GitHub URL
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',  # 选择一个开源许可协议，MIT许可为例
        'Operating System :: OS Independent',
    ],
)
